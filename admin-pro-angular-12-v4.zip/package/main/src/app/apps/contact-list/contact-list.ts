export class ContactLists {
    Id = 0;
    Imagepath: string | null | undefined = '';
    Name = '';
    Tags = '';
    Jobtitle = '';
    Company = '';
    Email = '';
    Phonenumber = 0;
    Address = '';
    DOB: Date | null = null;
    Description = '';
}
