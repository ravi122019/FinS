export class Contact {
    img = '';
    name = '';
    post = '';
    address = '';
    contactno = 0;
    insta = 0;
    linkedin = 0;
    facebook = 0;
}
